﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using fivemLuncher;

namespace FoesLauncher
{
    public partial class Form3 : Form
    {
        ayarlar RP = new ayarlar();
        public Form3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RP.zipIndir("https://s4.dosya.tc/server8/x13lge/Yeni_klasor__2_.rar.html", "Yeni_klasor_2.zip");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            RP.linkac("https://s2.dosya.tc/server11/1z3blb/silah_sesleri.rar.html");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            RP.linkac("https://drive.google.com/uc?authuser=0&id=0BzBx_UMF2Mc3UFRVSm9DVjVGXzg&export=download");
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            this.TransparencyKey = Color.Gray;
            this.BackColor = Color.Gray;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
        }
        protected override void OnLoad(EventArgs e) //mouse ile oynatma
        {
            if (this.FormBorderStyle == System.Windows.Forms.FormBorderStyle.None)
            {
                this.MouseDown += new MouseEventHandler(AppFormBase_MouseDown);
                this.MouseMove += new MouseEventHandler(AppFormBase_MouseMove);
                this.MouseUp += new MouseEventHandler(AppFormBase_MouseUp);
            }

            base.OnLoad(e);
        }

        void AppFormBase_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
            {
                return;
            }
            downPoint = new Point(e.X, e.Y);
        }

        void AppFormBase_MouseMove(object sender, MouseEventArgs e)
        {
            if (downPoint == Point.Empty)
            {
                return;
            }
            Point location = new Point(
                this.Left + e.X - downPoint.X,
                this.Top + e.Y - downPoint.Y);
            this.Location = location;
        }

        void AppFormBase_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
            {
                return;
            }
            downPoint = Point.Empty;
        }

        public Point downPoint = Point.Empty;

        private void button5_Click(object sender, EventArgs e)
        {
            RP.linkac("https://discord.gg/aApT5Qq");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            RP.linkac("https://discord.gg/aApT5Qq");
            this.TransparencyKey = Color.Gray;
            this.BackColor = Color.Gray;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
        }
    }
}
